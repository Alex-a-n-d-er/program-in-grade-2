﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Examine_and_approve_system
{
    public partial class ordercz : Form
    {
        public ordercz()
        {
            InitializeComponent();
            Table();
        }
        public void Table()
        {

            dataGridView1.Rows.Clear();//清空旧数据
            Dao dao = new Dao();
            string sql = "select * from approval_sys.approval";
            IDataReader dc = dao.read(sql);
            string approval_id, applicant_id, applicant_name, approver_id, approver_name, process_id, status;
            while (dc.Read())
            {
                  
                approval_id = dc[0].ToString();
                applicant_id = dc[1].ToString();
                applicant_name = dc[2].ToString();
                approver_id = dc[3].ToString();
                approver_name = dc[4].ToString();
                process_id = dc[5].ToString();
                status = dc[11].ToString();

                if (approver_id != Data.UID)//筛选自己的订单
                {
                    continue;
                }


                switch (dc[11])
                {
                    case -1:
                        status = "订单已取消";
                        break;
                    case 0:
                        status = "审批中";
                        break;
                    case 1:
                        status = "审批通过";
                        break;
                    case 2:
                        status = "审批驳回";
                        break;
                }

                string[] table = { approval_id, applicant_id, applicant_name, approver_id, approver_name, process_id, status };
                dataGridView1.Rows.Add(table);
            }
            dc.Close();
            dao.DaoClose();

        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();    //获取订单号
                label2.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                DialogResult dr = MessageBox.Show("是否确认通过申请？", "信息提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (dr == DialogResult.OK)
                {
                    string sql = $"update approval set _status = 0 where approval_id = '{id}'";
                    //string sql1 = $"update application_details set _status = -1 where apply_id = '{id}'";
                    Dao login = new Dao();
                    if (login.Execute(sql) > 0)
                    {
                        MessageBox.Show("操作成功");
                        Table();
                    }
                    else
                    {
                        MessageBox.Show("操作失败");
                    }
                    login.DaoClose();
                }

            }
            catch
            {

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
