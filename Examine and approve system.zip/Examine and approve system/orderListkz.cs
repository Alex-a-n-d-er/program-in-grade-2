﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Examine_and_approve_system
{
    public partial class orderListkz : Form
    {
        public int tlevel;
        public orderListkz(int s)
        {
            InitializeComponent();
            tlevel=s;
        }

        private void orderList_Load(object sender, EventArgs e)
        {
            
        }
    }
}
