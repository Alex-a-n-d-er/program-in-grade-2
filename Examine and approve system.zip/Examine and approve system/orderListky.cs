﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Examine_and_approve_system
{
    public partial class orderListky : Form
    {
        public int tlevel;
        public orderListky(int s)
        {
            InitializeComponent();
            tlevel = s;
        }


        private void orderListky_Load(object sender, EventArgs e)
        {

        }
    }
}
